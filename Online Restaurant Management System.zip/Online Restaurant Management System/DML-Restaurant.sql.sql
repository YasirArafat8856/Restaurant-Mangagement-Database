use Online_Restaurant_Management;
			-------------------insert values into restaurant info table-------------------
Exec Sp_ins_ResInfo 'Yasir Restaurant','Yasir Arafat','Mohammadpur Dhaka','+8801745678855','yasirarafat@gmail.com';

			-------------------insert values into Item table-------------------
go
Exec Sp_Ins_Item 'Biriyani',200;
Exec Sp_Ins_Item 'Kacchi',250;
Exec Sp_Ins_Item 'Teheri',150;
Exec Sp_Ins_Item 'Beef curry',180;
Exec Sp_Ins_Item 'Mutton curry',220;
Exec Sp_Ins_Item 'Chicken',150;
go
			-------------------insert values into Area table-------------------
Exec Sp_ins_area 'Dhanmondi';
Exec Sp_ins_area 'Mohammadpur';
Exec Sp_ins_area 'Mirpur';
go
			-------------------insert values into Delivery boy table-------------------
exec Sp_ins_Dboy 'Noman',1;
exec Sp_ins_Dboy 'Rohim',2;
exec Sp_ins_Dboy 'Korim',3;
Go
			-------------------insert values into customer table-----------------
Exec Sp_ins_Cus 'Sohag',1,'+8801736934574','sohag@Gmail.com'
Exec Sp_ins_Cus 'Mili',2,'+8801747034474','mili@Gmail.com'
Exec Sp_ins_Cus 'Imran',2,'+8801739724574','imran@Gmail.com'
Exec Sp_ins_Cus 'Mehedi',3,'+880112344574','mehedi@Gmail.com'
Exec Sp_ins_Cus 'Rayhan',1,'+8801736939876','rayhan@Gmail.com';
Go
			-------------------insert values into Food order table-------------------
exec Sp_ins_order 1,1,2;
exec Sp_ins_order 1,2,3;
exec Sp_ins_order 2,3,4;
exec Sp_ins_order 3,4,3;
exec Sp_ins_order 4,5,3;
exec Sp_ins_order 5,6,4;
exec Sp_ins_order 5,1,3;
go
			-------------------insert values into Bill table-------------------
Exec Sp_insBill 1,'Cash On Delivery';
Exec Sp_insBill 2,'Cash On Delivery';
Exec Sp_insBill 3,'Cash On Delivery';
Exec Sp_insBill 4,'Cash On Delivery';
Exec Sp_insBill 5,'Cash On Delivery';
Exec Sp_insBill 6,'Cash On Delivery';
Exec Sp_insBill 7,'Cash On Delivery';
go
			-------------------insert values into Delivery details table-------------------
Exec Sp_ord_dtl  1,1,1,'2019-07-17','delevered';
Exec Sp_ord_dtl  2,2,2,'2019-07-17','delevered';
Exec Sp_ord_dtl  3,3,3,'2019-07-17','delevered';
Exec Sp_ord_dtl  1,4,4,'2019-07-17','delevered';
Exec Sp_ord_dtl  2,5,5,'2019-07-18','delevered';
Exec Sp_ord_dtl  3,6,6,'2019-07-18','delevered';
Exec Sp_ord_dtl  1,1,7,'2019-07-18','delevered';
go
			-----------call scaler function---------
select dbo.Fn_TotalPrice('2019-07-01','2019-07-17') AS Total_Sale
			-----------call table function---------
select * from dbo.fn_sales() 
			-----------call all table and view ---------
select * from Restaurant_Info
select * from Customer
select * from Area
select * from Item
select * from Food_Order
select * from Bill
select * from Delivery_Details
select * from vw_all_details
			-----------index---------
exec sp_helpindex Customer










