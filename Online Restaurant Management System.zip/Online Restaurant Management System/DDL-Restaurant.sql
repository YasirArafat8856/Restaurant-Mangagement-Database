			--------------create database-----------------
use master
if DB_ID('Online_Restaurant_Management') is not null
drop database Online_Restaurant_Management
go
Create Database Online_Restaurant_Management;
go
use Online_Restaurant_Management;
go
				--------------create table-----------------

Create Table Restaurant_Info
(
	ID Int Identity Primary key,
	Restaurant_Name varchar(50),
	Owner_Name Varchar(50),
	Res_Address Varchar(100),
	Res_Contact_NO Varchar(20),
	Res_Email Varchar(20)
);
Create Table Item
(
	Id Int Identity Primary key,
	Item_Name Varchar(30),
	Item_Price Money
);
Create Table Area
(
	Id Int Identity Primary key,
	Area_Name Varchar(50)
);
Create Table Customer
(
	Id Int Identity Primary key,
	Customer_Name Varchar(30),
	Area_id int references Area(Id),
	Cus_Contact_NO Varchar(20),
	Cus_Email Varchar(20)
);
Create Table Delivery_Boy
(
	Id Int Identity Primary key,
	D_Boy_Name Varchar(50),
	Area_Id Int References Area(Id)
);
Create Table Food_Order
(
	Id Int Identity Primary key,
	Cus_Id Int References Customer(Id),
	Item_Id Int References Item(Id),
	Quantity Int,
	Total_Price Money
);
Create Table Bill
(
	Id Int Identity Primary key,
	Order_Id Int References Food_Order(Id),
	Total_Price Money default 0,
	Payment_Method varchar(30)
);
Create Table Delivery_Details
(
	Id Int Identity Primary key,
	D_Boy_Id Int References Delivery_Boy(Id),	
	Order_Id Int References Food_Order(Id),
	Bill_Id Int References Bill(Id),
	delivery_date date,
	D_Status Varchar(50)
);
GO
				--------------create procedure for insert Restaurant info-----------------
Create Proc Sp_ins_ResInfo
@ResN Varchar(50), @OwnerN Varchar(50), @ResAdd Varchar(100), @ResConNO Varchar(20), @ResEm Varchar(20)
As
Begin
	Insert Restaurant_Info
	Values(@ResN,@OwnerN,@ResAdd,@ResConNO,@ResEm)
End;
go
				--------------create procedure for insert Item Table-----------------
Create proc Sp_Ins_Item
@Iname Varchar(30), @Iprice Money
As
Begin
	Insert Into Item Values(@Iname,@Iprice)
End
go
				--------------create procedure for insert Area Table-----------------
create proc Sp_ins_area
@AreaName varchar(30)
AS
Begin
	Insert Area Values(@AreaName)
End
go
				--------------create procedure for insert Delivery Boy Table-----------------
Create proc Sp_ins_Dboy
@DboyN Varchar(50),@AreaId int
As
Begin
	Insert Delivery_Boy Values(@DboyN,@AreaId)
End;
go 
				--------------create procedure for insert Customer Table-----------------
create proc Sp_ins_Cus
@CusName varchar(30),@aid int,@CusConNO varchar(20),@CusEmail varchar(20)
AS
Begin
	Insert Customer Values(@CusName,@aid,@CusConNO,@CusEmail)
End
Go
				--------------create procedure for insert Food Order Table-----------------
create proc Sp_ins_order
@CusId int,@ItemId int,@Quantity int
AS
Begin
	declare @price money,@totalPrice money 
	select @price= Item_Price  from Item where Id= @ItemId
	set @totalPrice= @price*@Quantity;
	Insert Food_Order (Cus_Id,Item_Id,Quantity,Total_Price)
	Values(@CusId,@ItemId,@Quantity,@totalPrice)
End
Go
				--------------create trigger with transaction for insert bill and order table-----------------
create trigger tr_ins_bl
on food_order
instead of insert
as
begin
	
	declare @total int
	select @total=Total_Price from inserted;
	if (@total>150)
	begin
		begin try
			begin tran
				Insert Food_Order (Cus_Id,Item_Id,Quantity,Total_Price)
				select Cus_Id,Item_Id,Quantity,Total_Price from inserted
				
			commit tran
		end try
		begin catch
			print 'If you order something then Total price must be greater than 150'
			if @@TRANCOUNT>0 rollback tran
		end catch
	end
	else
	begin
		print 'If you order something then  Total price must be greater than 150'
		if @@TRANCOUNT>0 rollback tran
	end
		
end
go
				-----------------end or trigger---------------------

				--------------create procedure for insert Bill Table-----------------

create proc Sp_insBill
@ordId int,  @PayMath Varchar(30)
As
Begin
		Declare @tprice money
		select @tprice=Total_Price from Food_Order where Id=@ordId
		Insert Bill(Order_Id,Total_Price, Payment_Method) Values(@ordId,@tprice, @PayMath)
End
go

				--------------create procedure for insert Delivery Details Table-----------------
Create proc Sp_ord_dtl
@dBoyId int, @OrdId int,@BID int,@ddate date, @DStatus Varchar(50)
As
Begin
	Insert Delivery_Details Values(@dBoyId,@OrdId,@BID,@ddate,@DStatus)
End; 
go
				--------------create a view for all details-----------------
create view vw_all_details
as
	select Item_Name,Quantity,delivery_date, Customer_Name,D_Boy_Name,Area_Name,fo.Total_Price,D_Status,Payment_Method
	from Delivery_Details dd join Bill b
	on dd.Bill_Id=b.Id
	join Food_Order fo
	on b.Order_Id=fo.Id
	join Customer c 
	on fo.Cus_Id=c.Id
	join Item i
	on i.Id=fo.Item_Id
	join Area a
	on a.Id=c.Area_id
	join Delivery_Boy db
	on db.Id=dd.D_Boy_Id

GO
				--------------create a scalar funtion for total sales-----------------
Create function Fn_TotalPrice(@sdate date,@edate date)
	Returns money
Begin
	declare @total money
	Select @total=(select sum(total_price)from Vw_all_details
where delivery_date  between @sdate and @edate)
	return  @total
End
go
				--------------create a Table value funtion for total sales-----------------
create function fn_sales()
returns table
	return 
	select total_price from vw_all_details 
go
				--------------create a noncluster index-----------------
create index ix_cus
on customer(Customer_Name);





